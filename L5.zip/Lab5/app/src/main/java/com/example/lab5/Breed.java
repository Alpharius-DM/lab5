package com.example.lab5;

public class Breed
{
    public String id;
    public String name;
}
