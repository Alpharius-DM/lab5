package com.example.lab5;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class LikesAdapter extends RecyclerView.Adapter<LikesAdapter.ViewHolder>
{
    private LayoutInflater inflater;
    private ArrayList<Vote> votes;

    LikesAdapter(Context context, ArrayList<Vote> votes) {
        this.votes = votes;
        this.inflater = LayoutInflater.from(context);
    }
    @NonNull
    @Override
    public LikesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item_for_likes, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LikesAdapter.ViewHolder holder, int position) {
        final Vote vote = votes.get(position);
        if(vote.cat == null)
        {
            new CatLoadingTask(vote, holder.imageView, holder.textView).execute("https://api.thecatapi.com/v1/images/" + vote.image_id);
            return;
        }
        else if(vote.cat.image == null)
        {
            new DownloadImageTask(holder.imageView,holder.textView, vote).execute(vote.cat.url);
            return;
        }
        else
        {
            holder.imageView.setImageBitmap(vote.cat.image);
            if(vote.value == 1)
                holder.textView.setText("  like");
            else
                holder.textView.setText("  dislike");
        }
    }

    @Override
    public int getItemCount() {
        return votes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView imageView;
        final TextView textView;
        ViewHolder(View view){
            super(view);
            imageView = (ImageView)view.findViewById(R.id.imageViewForLikes);
            textView = (TextView)view.findViewById(R.id.textForLikes);
        }
    }
}
class CatLoadingTask extends AsyncTask<String, Void, String> {
    private Vote vote;
    private ImageView imageView;
    private TextView textView;
    public CatLoadingTask(Vote vote, ImageView imageView, TextView textView)
    {
        this.vote = vote;
        this.imageView = imageView;
        this.textView = textView;
    }
    @Override
    protected String doInBackground(String... path) {

        String content;
        try{
            content = getContent(path[0]);
        }
        catch (IOException ex){
            content = ex.getMessage();
        }
        return content;
    }
    @Override
    protected void onPostExecute(String content)
    {
        Cat cat = new Gson().fromJson(content, new TypeToken<Cat>() {}.getType());
        this.vote.cat = cat;
        new DownloadImageTask(imageView, textView, vote).execute(vote.cat.url);
    }

    private String getContent(String path) throws IOException {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(path)
                .get()
                .addHeader("x-api-key", "cf3b4032-b39f-4ce0-81da-1886c1036c78")
                .build();

        Response response = client.newCall(request).execute();
        return  response.body().string();
    }
}


class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
    ImageView bmImage;
    TextView textView;
    Vote vote;
    public DownloadImageTask(ImageView bmImage, TextView textView, Vote vote) {
        this.bmImage = bmImage;
        this.textView = textView;
        this.vote = vote;
    }

    protected Bitmap doInBackground(String... urls) {
        String urldisplay = urls[0];
        Bitmap mIcon11 = null;
        try {
            InputStream in = new java.net.URL(urldisplay).openStream();
            mIcon11 = BitmapFactory.decodeStream(in);
            in.close();
        } catch (Exception e) {
            Log.e("Ошибка передачи файла", e.getMessage());
            e.printStackTrace();
        }
        return mIcon11;
    }

    protected void onPostExecute(Bitmap result) {
        bmImage.setImageBitmap(result);
        vote.cat.image = result;
        if(vote.value == 1)
            textView.setText("  like");
        else
            textView.setText("  dislike");
    }
}