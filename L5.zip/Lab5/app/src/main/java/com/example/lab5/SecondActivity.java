package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class SecondActivity extends AppCompatActivity {

    public ArrayList<Cat> cats;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Bundle arguments = getIntent().getExtras();
        String breed = arguments.get(MainActivity.BreedKey).toString();
        for(int i = 0; i < MainActivity.breeds.size(); i++)
        {
            if(MainActivity.breeds.get(i).name.equals(breed))
            {
                new LoadTask(this).execute("https://api.thecatapi.com/v1/images/search?breed_id="
                        + MainActivity.breeds.get(i).id + "&limit=100");
                break;
            }
        }

    }
    public class LoadTask extends AsyncTask<String, Void, String> {
        private SecondActivity act;
        public LoadTask(SecondActivity act)
        {
            this.act = act;
        }
        @Override
        protected String doInBackground(String... path) {

            String content;
            try{
                content = getContent(path[0]);
            }
            catch (IOException ex){
                content = ex.getMessage();
            }
            return content;
        }
        @Override
        protected void onPostExecute(String content) {
            cats = new Gson().fromJson(content, new TypeToken<List<Cat>>() {}.getType());
            DataAdapter adapter = new DataAdapter(act, cats);
            RecyclerView recyclerView = (RecyclerView)act.findViewById(R.id.list);
            recyclerView.setAdapter(adapter);
            act = null;
        }

        private String getContent(String path) throws IOException {
            BufferedReader reader=null;
            try {
                URL url=new URL(path);
                HttpsURLConnection c=(HttpsURLConnection)url.openConnection();
                c.setRequestMethod("GET");
                c.setReadTimeout(10000);
                c.connect();
                reader= new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder buf=new StringBuilder();
                String line=null;
                while ((line=reader.readLine()) != null) {
                    buf.append(line + "\n");
                }
                return(buf.toString());
            }
            finally {
                if (reader != null) {
                    reader.close();
                }
            }
        }
    }

}
