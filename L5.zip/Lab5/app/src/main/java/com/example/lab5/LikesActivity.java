package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class LikesActivity extends AppCompatActivity {

    private ArrayList<Vote> votes;
    private RecyclerView listForVotes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_likes);
        listForVotes = (RecyclerView)findViewById(R.id.listForLikes);
        new LoadLikesTask(this).execute("https://api.thecatapi.com/v1/votes?sub_id=" + MainActivity.User);

    }
    public void onPostExecute(String content)
    {
        votes = new Gson().fromJson(content, new TypeToken<List<Vote>>() {}.getType());
        if(votes.size() > 10)
        {
            ArrayList<Vote> newVotes = new ArrayList<>();
            for (int i = votes.size() - 1; i > votes.size() - 11; i--)
            {
                newVotes.add(votes.get(i));
            }
            votes = newVotes;
        }
        LikesAdapter adapter = new LikesAdapter(this, votes);
        listForVotes.setAdapter(adapter);
    }
}
class LoadLikesTask extends AsyncTask<String, Void, String>
{
    LikesActivity act;
    public LoadLikesTask(LikesActivity act)
    {
        this.act = act;
    }

    @Override
    protected String doInBackground(String... path) {
        String content;
        try{
            content = getContent(path[0]);
        }
        catch (IOException ex){
            content = ex.getMessage();
        }
        return content;
    }
    @Override
    protected void onPostExecute(String content)
    {
        act.onPostExecute(content);
        act = null;
    }

    private String getContent(String path) throws IOException
    {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(path)
                .get()
                .addHeader("x-api-key", "cf3b4032-b39f-4ce0-81da-1886c1036c78")
                .build();

        Response response = client.newCall(request).execute();
        return response.body().string();
    }

}