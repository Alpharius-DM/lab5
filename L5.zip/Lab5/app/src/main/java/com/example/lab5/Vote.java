package com.example.lab5;

public class Vote
{
    public int id;
    public String image_id;
    public int value;
    public Cat cat;
}
