package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    public static String BreedKey = "Breed_Key";
    public static String User = "sub_user_3";
    public static ArrayList<Breed> breeds;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new LoadTask(this).execute("https://api.thecatapi.com/v1/breeds");


    }
    @Override
    protected void onPause()
    {
        super.onPause();

    }
    public void seeLastLikes(View view)
    {
        Intent intent = new Intent(this, LikesActivity.class);
        startActivity(intent);
    }
    public void search(View view)
    {
        Spinner spinner = findViewById(R.id.breeds);

        if(spinner.getSelectedItem() != null)
        {
            Intent intent = new Intent(this, SecondActivity.class);
            intent.putExtra(BreedKey, spinner.getSelectedItem().toString());
            startActivity(intent);
        }
    }
    public void onPostExecute(String content)
    {
        breeds = new Gson().fromJson(content, new TypeToken<List<Breed>>() {}.getType());

        Spinner spinner = findViewById(R.id.breeds);
        ArrayList<String> names = new ArrayList<>();
        for(int i = 0; i < breeds.size(); i++)
        {
            names.add(breeds.get(i).name);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
    public class LoadTask extends AsyncTask<String, Void, String> {
        private MainActivity act;
        public LoadTask(MainActivity act)
        {
            this.act = act;
        }
        @Override
        protected String doInBackground(String... path) {

            String content;
            try{
                content = getContent(path[0]);
            }
            catch (IOException ex){
                content = ex.getMessage();
            }
            return content;
        }
        @Override
        protected void onPostExecute(String content) {
            act.onPostExecute(content);
            act=null;
        }

        private String getContent(String path) throws IOException {
            BufferedReader reader=null;
            try {
                URL url=new URL(path);
                HttpsURLConnection c=(HttpsURLConnection)url.openConnection();
                c.setRequestMethod("GET");
                c.setReadTimeout(10000);
                c.connect();
                reader= new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder buf=new StringBuilder();
                String line=null;
                while ((line=reader.readLine()) != null) {
                    buf.append(line + "\n");
                }
                return(buf.toString());
            }
            finally {
                if (reader != null) {
                    reader.close();
                }
            }
        }
    }
}

