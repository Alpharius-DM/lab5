package com.example.lab5;

import android.graphics.Bitmap;

import java.util.List;

public class Cat
{
    public String id;
    public String url;
    public Bitmap image = null;
}
