package com.example.lab5;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder>
{
    private LayoutInflater inflater;
    private ArrayList<Cat> cats;

    DataAdapter(Context context, ArrayList<Cat> cats) {
        this.cats = cats;
        this.inflater = LayoutInflater.from(context);
    }
    @NonNull
    @Override
    public DataAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataAdapter.ViewHolder holder, int position) {
        final Cat cat = cats.get(position);
        if(cat.image == null)
        {
            new DownloadImageTask(holder.imageView, cat).execute(cat.url);
        }
        else
        {
            holder.imageView.setImageBitmap(cat.image);
        }

        holder.butLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LoadTaskForVotes(cat.id, MainActivity.User, "1").execute("https://api.thecatapi.com/v1/votes");
            }
        });
        holder.butDisLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LoadTaskForVotes(cat.id, MainActivity.User, "0").execute("https://api.thecatapi.com/v1/votes");
            }
        });
    }

    @Override
    public int getItemCount() {
        return cats.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView imageView;
        final Button butLike, butDisLike;
        ViewHolder(View view){
            super(view);
            imageView = (ImageView)view.findViewById(R.id.imageView);
            butLike = (Button)view.findViewById(R.id.like);
            butDisLike = (Button)view.findViewById(R.id.dislike);
        }
    }
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {

        ImageView bmImage;
        Cat cat;
        public DownloadImageTask(ImageView bmImage, Cat cat) {
            this.bmImage = bmImage;
            this.cat = cat;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception e) {
                Log.e("Ошибка передачи файла", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
            cat.image = result;
        }
    }
    public class LoadTaskForVotes extends AsyncTask<String, Void, Void> {
        String imageId;
        String subId;
        String value;

        public LoadTaskForVotes(String imageId, String subId, String value)
        {
            this.imageId = imageId;
            this.subId = subId;
            this.value = value;
        }
        @Override
        protected Void doInBackground(String... path) {

            try{
                postRequest(path[0]);
            }
            catch (IOException ex){

            }
            return  null;
        }

        private void postRequest(String path) throws IOException {
            String parameters = "{\"image_id\":\"" + imageId + "\",\"sub_id\":\"" + subId +"\",\"value\":" + value + "}";

            OkHttpClient client = new OkHttpClient();

            MediaType mediaType = MediaType.parse("application/json");
            RequestBody body = RequestBody.create(mediaType, parameters);
            Request request = new Request.Builder()
                    .url(path)
                    .post(body)
                    .addHeader("content-type", "application/json")
                    .addHeader("x-api-key", "cf3b4032-b39f-4ce0-81da-1886c1036c78")
                    .build();

            client.newCall(request).execute();
        }
    }
}
